import { Component } from '@angular/core';

@Component({
  selector: 'app',
  // templateUrl: './app.component.html',
  //template: '<div class="bg-success p-2 text-center text-white">This is SportsStore</div>',
  //template: "<store></store>",
  template: "<router-outlet></router-outlet>",
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'SportsStore';
}
